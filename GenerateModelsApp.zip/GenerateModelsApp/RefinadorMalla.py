"""Refinamiento triangular independiente de Blender para evaluar patrones."""

from __future__ import annotations

import numpy as np

from .Excepciones import NormalesInvalidas, SuperficieInvalida
from .Malla import AnalizadorMalla
from .util.Utilidades import Configuracion, Registro


class RefinadorMalla:
    """Divide únicamente las aristas largas y conserva una superficie conectada."""

    @staticmethod
    def PasoPatron(opciones: dict) -> float:
        """Entrada: parámetros validados. Proceso: limita el paso según el patrón.
        Salida: paso máximo en mm. Errores: claves ausentes. Efectos: ninguno.
        """
        paso = float(opciones["surface_step_mm"])
        if opciones["pattern"] != "SOLID":
            paso = min(paso, float(opciones["rib_width_mm"]) / 3, float(opciones["cell_mm"]) / 6)
        return paso

    @staticmethod
    def AristaMayor(puntos: np.ndarray, caras: np.ndarray) -> float:
        """Entrada: malla triangular. Proceso: mide sus aristas. Salida: longitud
        máxima en mm, o cero para malla vacía. Efectos secundarios: ninguno.
        """
        if len(caras) == 0 or len(puntos) == 0:
            return 0.0
        pares = np.vstack((caras[:, [0, 1]], caras[:, [1, 2]], caras[:, [2, 0]]))
        return float(np.linalg.norm(puntos[pares[:, 0]] - puntos[pares[:, 1]], axis=1).max())

    @staticmethod
    def Refinar(vertices, caras, normales, pasoMm: float):
        if not np.isfinite(pasoMm) or pasoMm <= 0:
            raise SuperficieInvalida("El paso de la superficie debe ser positivo y finito.")

        puntos = np.asarray(vertices, dtype=np.float64)
        faces = np.asarray(caras, dtype=np.int32)
        normals = np.asarray(normales, dtype=np.float64)
        limite = int(Configuracion.ValorLimite("max_surface_vertices"))
        rondas = int(Configuracion.ValorLimite("surface_subdivision_iterations"))
        epsilon = Configuracion.ValorLimite("normal_epsilon")

        detenida = False
        for _ in range(rondas):
            todas = np.vstack(
                [faces[:, [0, 1]], faces[:, [1, 2]], faces[:, [2, 0]]]
            )
            aristas = np.unique(np.sort(todas, axis=1), axis=0)
            longitudes = np.linalg.norm(
                puntos[aristas[:, 0]] - puntos[aristas[:, 1]],
                axis=1,
            )
            largas = aristas[longitudes > pasoMm * 1.001]
            if not len(largas):
                break
            if len(puntos) + len(largas) > limite:
                # El tamaño en milímetros ya está decidido. No se parte más.
                detenida = True
                break

            inicio = len(puntos)
            indices = {
                (int(a), int(b)): inicio + posicion
                for posicion, (a, b) in enumerate(largas)
            }
            nuevos_puntos = (puntos[largas[:, 0]] + puntos[largas[:, 1]]) * 0.5
            nuevas_normales = normals[largas[:, 0]] + normals[largas[:, 1]]
            longitudes_normales = np.linalg.norm(nuevas_normales, axis=1)
            if np.any(longitudes_normales < epsilon):
                raise NormalesInvalidas(
                    detalle="Dos normales opuestas impiden refinar una arista."
                )
            nuevas_normales /= longitudes_normales[:, None]

            nuevas_caras = []
            for a, b, c in faces:
                a, b, c = int(a), int(b), int(c)
                ab = indices.get((min(a, b), max(a, b)))
                bc = indices.get((min(b, c), max(b, c)))
                ca = indices.get((min(c, a), max(c, a)))
                mascara = (ab is not None, bc is not None, ca is not None)

                if mascara == (False, False, False):
                    nuevas_caras.append((a, b, c))
                elif mascara == (True, False, False):
                    nuevas_caras.extend(((a, ab, c), (ab, b, c)))
                elif mascara == (False, True, False):
                    nuevas_caras.extend(((b, bc, a), (bc, c, a)))
                elif mascara == (False, False, True):
                    nuevas_caras.extend(((c, ca, b), (ca, a, b)))
                elif mascara == (True, True, False):
                    nuevas_caras.extend(((b, bc, ab), (a, ab, bc), (a, bc, c)))
                elif mascara == (False, True, True):
                    nuevas_caras.extend(((c, ca, bc), (b, bc, ca), (b, ca, a)))
                elif mascara == (True, False, True):
                    nuevas_caras.extend(((a, ab, ca), (c, ca, ab), (c, ab, b)))
                else:
                    nuevas_caras.extend(
                        (
                            (a, ab, ca),
                            (ab, b, bc),
                            (ca, bc, c),
                            (ab, bc, ca),
                        )
                    )

            puntos = np.vstack((puntos, nuevos_puntos))
            normals = np.vstack((normals, nuevas_normales))
            faces = np.asarray(nuevas_caras, dtype=np.int32)

        todas = np.vstack(
            [faces[:, [0, 1]], faces[:, [1, 2]], faces[:, [2, 0]]]
        )
        aristas = np.unique(np.sort(todas, axis=1), axis=0)
        if not detenida and np.any(
            np.linalg.norm(
                puntos[aristas[:, 0]] - puntos[aristas[:, 1]],
                axis=1,
            )
            > pasoMm * 1.001
        ):
            raise SuperficieInvalida(
                "No se alcanzó el paso de superficie. "
                "Aumente el paso o revise las unidades en mm."
            )
        if detenida:
            Registro.Obtener("malla").info(
                "Subdivisión detenida en %s vértices, por debajo del paso %.3f mm.",
                len(puntos),
                pasoMm,
            )

        Registro.Obtener("malla").info(
            "Superficie refinada sin Blender: %s vértices, %s triángulos, paso %.3f mm.",
            len(puntos),
            len(faces),
            pasoMm,
        )
        return AnalizadorMalla.Preparar(
            puntos,
            faces,
            normals,
            suavizarNormales=True,
        )
